from flask import Flask, render_template, request, redirect, url_for, session, flash
from data import get_new_arrivals, get_top_selling, get_styles

app = Flask(__name__)

USERNAME = 'Siti'
PASSWORD = '1'
app.secret_key = 'Admin12345'

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route("/login", methods=["GET", "POST"])
def login():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    else :
            if request.method == "POST":
                username = request.form['username']
                password = request.form['password']

                if username == USERNAME and password == PASSWORD:
                    session['username'] = username
                    return redirect(url_for('dashboard'))
                else:
                    flash('username atau password salah', 'error')
                    return redirect(url_for('login'))
            return render_template("login.html")
    
@app.route("/register")
def register():
    return render_template("register.html")

# @app.route("/dashbord")
# def dashboard():
#     if 'username' in session:
#         return render_template('dashboard.html',                       
#     username=session['username'])
#     else:
#         flash('Silakan login terlebih dahulu', 'error')
#     return redirect(url_for('login.html'))

@app.route("/dashboard")
def dashboard():
    if 'username' in session:
        new_arrivals = get_new_arrivals()
        top_selling = get_top_selling()
        styles = get_styles()
        return render_template('dashboard.html', 
                               new_arrivals=new_arrivals, 
                               top_selling=top_selling, 
                               styles=styles,
                               username=session['username'])
    else:
        flash('Silakan login terlebih dahulu', 'error')
    return redirect(url_for('login.html'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Anda telah logout', 'info')
    return redirect(url_for('login'))

if __name__ == "__main__":
    app.run(debug=True)
